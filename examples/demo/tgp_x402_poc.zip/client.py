
import httpx, base64, json, os
from tdr_logger import tdr_write

RESOURCE = os.environ.get("RESOURCE_URL", "http://127.0.0.1:8000/weather")
FAC_A = os.environ.get("FAC_A", "http://127.0.0.1:8001")
FAC_B = os.environ.get("FAC_B", "http://127.0.0.1:8002")

def b64(obj):
    return base64.b64encode(json.dumps(obj).encode()).decode()

def main():
    print("1) Requesting resource → expect 402 + PaymentRequirements...")
    r = httpx.get(RESOURCE, timeout=5.0)
    print("Status:", r.status_code)
    pr = r.json()
    print("Payment Required Response:", json.dumps(pr, indent=2))

    payreq = pr["accepts"][0]
    amount = payreq["maxAmountRequired"]

    # 2) Ask both facilitators for TGP quotes
    print("\n2) Asking facilitators for TGP route quotes...")
    qbody = {"x402Version":1,"resource": payreq["resource"],"paymentRequirements": payreq,"amount": amount,"hints":{"latencyMsMax":250}}
    qa = httpx.post(f"{FAC_A}/tgp/route/quote", json=qbody, timeout=5.0).json()
    qb = httpx.post(f"{FAC_B}/tgp/route/quote", json=qbody, timeout=5.0).json()
    print("Quote A:", json.dumps(qa, indent=2))
    print("Quote B:", json.dumps(qb, indent=2))

    # 3) Pick lowest surcharge (B in this mock), build X-PAYMENT header
    surcharge_a = int(qa["paths"][0]["quote"]["totalSurcharge"])
    surcharge_b = int(qb["paths"][0]["quote"]["totalSurcharge"])
    chosen = FAC_A if surcharge_a <= surcharge_b else FAC_B
    print(f"Choosing facilitator: {chosen}")

    payment_payload = {
        "x402Version": 1,
        "scheme": payreq["scheme"],
        "network": payreq["network"],
        "payload": {"amount": amount, "asset": payreq["asset"], "payTo": payreq["payTo"]},
        # Not part of x402 header in production; included here ONLY to hint the server which facilitator we picked
        "facilitatorUrl": chosen
    }
    header_value = b64(payment_payload)

    # 4) Retry with X-PAYMENT
    print("\n4) Retrying with X-PAYMENT header...")
    r2 = httpx.get(RESOURCE, headers={"X-PAYMENT": header_value}, timeout=5.0)
    print("Status:", r2.status_code)
    print("Body:", r2.text)

    xpr = r2.headers.get("X-PAYMENT-RESPONSE")
    if xpr:
        print("X-PAYMENT-RESPONSE (decoded):", json.loads(base64.b64decode(xpr).decode()))

    tdr_write("demo_complete", {"chosen_facilitator": chosen, "status": r2.status_code})

if __name__ == "__main__":
    main()
