
# TGP-on-x402 Demo (Mocked) — "Show, don't tell"

A tiny, **runnable** proof-of-concept that demonstrates **TGP discovery/quoting** layered above **x402**-style payment, while **keeping settlement single-hop** (client → payTo).

This PoC uses **mock facilitators** (`/verify`, `/settle` succeed without chain calls) so you can record a ≤2‑minute screen capture to satisfy the x402 team's **"show, don’t tell"** request. Swap the mock facilitators for real ones later.

## What it shows
- `402 Payment Required` response with **x402 PaymentRequirements**.
- **TGP discovery** call (`/tgp/route/quote`) returning paths, attributes, and a quote.
- Client **selects a facilitator** from TGP results.
- Client **retries** with `X-PAYMENT` header (base64 JSON payload).
- Resource server **calls facilitator `/verify` and `/settle`** (mocked) and returns `200 OK`.
- **TDR logs** written as flat JSON lines (one per event) to `./tdr/`.

## Layout
```
.
├─ facilitator_a.py        # Facilitator A (mock /verify, /settle, /supported, /tgp/route/quote)
├─ facilitator_b.py        # Facilitator B (same, different attrs)
├─ resource_server.py      # x402-like resource (returns 402, then 200 after verify/settle)
├─ client.py               # Orchestrates the whole demo; prints clear steps
├─ tdr_logger.py           # Flat-file JSONL logger
├─ requirements.txt        # FastAPI + Uvicorn + HTTPX + Pydantic
└─ README.md
```

## Quick start (one terminal per service)

### 1) Install deps
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

### 2) Start Facilitator A
```bash
uvicorn facilitator_a:app --port 8001 --log-level warning
```

### 3) Start Facilitator B
```bash
uvicorn facilitator_b:app --port 8002 --log-level warning
```

### 4) Start Resource Server
```bash
uvicorn resource_server:app --port 8000 --log-level warning
```

### 5) Run the demo client (in a new terminal)
```bash
python client.py
```

Expected flow in the client output:
1. GET /weather → 402 + PaymentRequirements (+ optional routes)
2. POST Facilitator /tgp/route/quote → returns paths/quotes
3. Build X-PAYMENT header; retry GET /weather
4. Resource calls Facilitator /verify and /settle → success
5. Receive 200 OK with weather JSON + `X-PAYMENT-RESPONSE` header
6. Check `./tdr/` for JSONL logs (policy, route, verify, settle, deliver)

## Record it
- Start a screen recorder.
- Show the three servers running.
- Run `python client.py` and scroll the console + show `tdr/` files.
- Done — you have a **<2‑minute** demo.

## Swap in real facilitators later
- Point `FACILITATOR_URL` env var in `client.py` or accept the route hints returned by resource.
- Keep the same sequence; only the facilitator endpoints change.

