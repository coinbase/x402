
from fastapi import FastAPI
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import base64, json
from tdr_logger import tdr_write

app = FastAPI(title="Facilitator A (mock)")

class PaymentRequirements(BaseModel):
    scheme: str
    network: str
    maxAmountRequired: str
    resource: str
    description: str
    mimeType: str
    outputSchema: Optional[dict] = None
    payTo: str
    maxTimeoutSeconds: int
    asset: str
    extra: Optional[dict] = None

class VerifyReq(BaseModel):
    x402Version: int
    paymentHeader: str
    paymentRequirements: PaymentRequirements

class VerifyResp(BaseModel):
    isValid: bool
    invalidReason: Optional[str] = None

class SettleReq(VerifyReq):
    pass

class SettleResp(BaseModel):
    success: bool
    error: Optional[str] = None
    txHash: Optional[str] = None
    networkId: Optional[str] = None

@app.get("/supported")
def supported():
    return {"kinds":[{"scheme":"exact", "network":"eip3009:base"}]}

@app.post("/verify", response_model=VerifyResp)
def verify(body: VerifyReq):
    # Mock decode + trivial checks
    try:
        decoded = json.loads(base64.b64decode(body.paymentHeader).decode())
        assert decoded.get("scheme") == body.paymentRequirements.scheme
        assert decoded.get("network") == body.paymentRequirements.network
    except Exception as e:
        tdr_write("verify_fail", {"facilitator":"A","reason":str(e)})
        return {"isValid": False, "invalidReason": "bad_header"}
    tdr_write("verify_ok", {"facilitator":"A","payTo":body.paymentRequirements.payTo})
    return {"isValid": True, "invalidReason": None}

@app.post("/settle", response_model=SettleResp)
def settle(body: SettleReq):
    # Mock success; generate fake tx hash
    tx = "0x" + ("a"*64)
    tdr_write("settle_ok", {"facilitator":"A","tx":tx})
    return {"success": True, "error": None, "txHash": tx, "networkId": body.paymentRequirements.network}

# TGP route quote — mocked path with attributes
class QuoteReq(BaseModel):
    x402Version: int
    resource: str
    paymentRequirements: PaymentRequirements
    amount: str
    hints: Optional[Dict[str, Any]] = None

@app.post("/tgp/route/quote")
def tgp_quote(req: QuoteReq):
    tdr_write("tgp_quote", {"facilitator":"A","resource":req.resource,"amount":req.amount})
    return {
        "paths":[{
            "taPath":["ta:us-west-1","ta:exchange-A","ta:eu-central"],
            "facilitators":[{"url":"http://127.0.0.1:8001","attrs":{"sla":"99.95","priceBps":2}}],
            "quote":{"totalSurcharge":"120","advisory":["kyc:light","aml:screening"]},
            "proof":{"type":"reachability","evidence":"mock-signature"}
        }],
        "cacheTtlSeconds":60
    }
