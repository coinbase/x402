
import os, json, time, uuid, pathlib

TDR_DIR = os.environ.get("TDR_DIR", "./tdr")
pathlib.Path(TDR_DIR).mkdir(parents=True, exist_ok=True)

def tdr_write(event_type: str, data: dict):
    rec = {
        "ts": int(time.time()*1000),
        "event": event_type,
        "id": str(uuid.uuid4()),
        **data
    }
    fn = os.path.join(TDR_DIR, "tdr.log")
    with open(fn, "a") as f:
        f.write(json.dumps(rec) + "\n")
    return rec
