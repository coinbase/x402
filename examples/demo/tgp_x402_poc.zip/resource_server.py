
from fastapi import FastAPI, Header, Response
from typing import Optional, List, Dict, Any
import base64, json, os, httpx
from pydantic import BaseModel
from tdr_logger import tdr_write

FACILITATOR_HINTS = [
    {"facilitator":"http://127.0.0.1:8001","attrs":{"sla":"99.95","jurisdiction":"US"}},
    {"facilitator":"http://127.0.0.1:8002","attrs":{"sla":"99.9","jurisdiction":"EU"}}
]

app = FastAPI(title="x402-like Resource (mock)")

class PaymentRequirements(BaseModel):
    scheme: str
    network: str
    maxAmountRequired: str
    resource: str
    description: str
    mimeType: str
    outputSchema: Optional[dict] = None
    payTo: str
    maxTimeoutSeconds: int
    asset: str
    extra: Optional[dict] = None

def payment_required_response():
    pr = {
        "x402Version": 1,
        "accepts": [{
            "scheme":"exact",
            "network":"eip3009:base",
            "maxAmountRequired":"100000",
            "resource":"http://127.0.0.1:8000/weather",
            "description":"Weather JSON",
            "mimeType":"application/json",
            "payTo":"0xResourcePayee",
            "maxTimeoutSeconds": 30,
            "asset":"0xA0b86991",  # USDC-like mock
            "extra":{"name":"USDC","version":"3009"}
        }],
        "routes":[
            {"facilitator": FACILITATOR_HINTS[0]["facilitator"], "attrs": FACILITATOR_HINTS[0]["attrs"], "cacheTtlSeconds":60},
            {"facilitator": FACILITATOR_HINTS[1]["facilitator"], "attrs": FACILITATOR_HINTS[1]["attrs"], "cacheTtlSeconds":60}
        ]
    }
    return pr

@app.get("/weather")
async def weather(x_payment: Optional[str] = Header(None), response: Response = None):
    if not x_payment:
        response.status_code = 402
        return payment_required_response()

    # Decode header and select facilitator (client embeds facilitator url for demo simplicity)
    try:
        decoded = json.loads(base64.b64decode(x_payment).decode())
        facilitator_url = decoded.get("facilitatorUrl", FACILITATOR_HINTS[0]["facilitator"])
        payreq = payment_required_response()["accepts"][0]
        tdr_write("request_with_payment", {"facilitatorUrl": facilitator_url})
        async with httpx.AsyncClient(timeout=5.0) as client:
            vr = await client.post(f"{facilitator_url}/verify", json={
                "x402Version":1,
                "paymentHeader": x_payment,
                "paymentRequirements": payreq
            })
            vj = vr.json()
            if not vj.get("isValid"):
                response.status_code = 402
                return payment_required_response()
            sr = await client.post(f"{facilitator_url}/settle", json={
                "x402Version":1,
                "paymentHeader": x_payment,
                "paymentRequirements": payreq
            })
            sj = sr.json()
            if not sj.get("success"):
                response.status_code = 402
                return payment_required_response()
    except Exception as e:
        response.status_code = 500
        return {"error": str(e)}

    # Success
    settlement_resp = {"txHash": sj.get("txHash"), "networkId": sj.get("networkId")}
    response.headers["X-PAYMENT-RESPONSE"] = base64.b64encode(json.dumps(settlement_resp).encode()).decode()
    tdr_write("deliver_ok", {"settlement": settlement_resp})
    return {"tempC": 21.5, "city": "Lisbon", "source": "mock"}
