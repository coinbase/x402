
from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional, Dict, Any
import base64, json
from tdr_logger import tdr_write

app = FastAPI(title="Facilitator B (mock)")

class PaymentRequirements(BaseModel):
    scheme: str
    network: str
    maxAmountRequired: str
    resource: str
    description: str
    mimeType: str
    outputSchema: Optional[dict] = None
    payTo: str
    maxTimeoutSeconds: int
    asset: str
    extra: Optional[dict] = None

class VerifyReq(BaseModel):
    x402Version: int
    paymentHeader: str
    paymentRequirements: PaymentRequirements

class VerifyResp(BaseModel):
    isValid: bool
    invalidReason: Optional[str] = None

class SettleReq(VerifyReq):
    pass

class SettleResp(BaseModel):
    success: bool
    error: Optional[str] = None
    txHash: Optional[str] = None
    networkId: Optional[str] = None

@app.get("/supported")
def supported():
    return {"kinds":[{"scheme":"exact", "network":"eip3009:base"}]}

@app.post("/verify", response_model=VerifyResp)
def verify(body: VerifyReq):
    try:
        decoded = json.loads(base64.b64decode(body.paymentHeader).decode())
        assert decoded.get("scheme") == body.paymentRequirements.scheme
        assert decoded.get("network") == body.paymentRequirements.network
    except Exception as e:
        tdr_write("verify_fail", {"facilitator":"B","reason":str(e)})
        return {"isValid": False, "invalidReason": "bad_header"}
    tdr_write("verify_ok", {"facilitator":"B","payTo":body.paymentRequirements.payTo})
    return {"isValid": True, "invalidReason": None}

@app.post("/settle", response_model=SettleResp)
def settle(body: SettleReq):
    tx = "0x" + ("b"*64)
    tdr_write("settle_ok", {"facilitator":"B","tx":tx})
    return {"success": True, "error": None, "txHash": tx, "networkId": body.paymentRequirements.network}

class QuoteReq(BaseModel):
    x402Version: int
    resource: str
    paymentRequirements: PaymentRequirements
    amount: str
    hints: Optional[Dict[str, Any]] = None

@app.post("/tgp/route/quote")
def tgp_quote(req: QuoteReq):
    tdr_write("tgp_quote", {"facilitator":"B","resource":req.resource,"amount":req.amount})
    return {
        "paths":[{
            "taPath":["ta:us-east-1","ta:exchange-B","ta:eu-west"],
            "facilitators":[{"url":"http://127.0.0.1:8002","attrs":{"sla":"99.9","priceBps":1}}],
            "quote":{"totalSurcharge":"80","advisory":["kyc:none"]},
            "proof":{"type":"reachability","evidence":"mock-signature"}
        }],
        "cacheTtlSeconds":60
    }
